package book_rent;

import java.util.ArrayList;
import java.util.Scanner;

import OnBarcode.Barcode.BarcodeScanner.BarcodeScanner;
import OnBarcode.Barcode.BarcodeScanner.BarcodeType;

public class Member {
	
	public static void changeEmail(ArrayList<String[]> currentUsers, int foundIndex) {
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter your new email: ");
		String newEmail = reader.nextLine();
		if (newEmail.contains("@gmail.com")) {
			currentUsers.get(foundIndex)[2] = newEmail;
			System.out.println("Email Successfully Changed.");
		} else {
			System.out.println("Failed to change Email address. Reason: Invalid email address.");
		}
	}
	
	public static void rentBook(ArrayList<String[]> currentUsers, ArrayList<String[]> currentBooks, ArrayList<String[]> currentRent, int foundIndex) {
		Scanner reader = new Scanner(System.in);
		Data rent = new Data(currentRent);
		String[] data = {};
		while (data.length == 0) {
			System.out.print("Scan the barcode on the book with the scanner e.g. C:\\Users\\wwwth\\OneDrive\\Desktop\\Barcode\\Barcode.png: ");
			String folderPath = reader.nextLine();
			data = BarcodeScanner.Scan(folderPath, BarcodeType.Code128);
		}
		final String bookCode = data[0];
		String userName = currentUsers.get(foundIndex)[0];
		boolean bookExist = false;
		for (int i = 0; i < currentBooks.size(); i++) {
			
		    if (bookCode.substring(1).equals(currentBooks.get(i)[3].substring(1))) {
		    	bookExist = true;
		    	
		        if (currentRent.isEmpty()) {
		            rent.setRentArr(currentRent, userName, currentBooks.get(i)[3]);
		            break;
		        }

		        boolean alreadyScanned = false;
		        for (int j = 0; j < currentRent.size(); j++) {
		            if (bookCode.substring(1).equals(currentRent.get(j)[1].substring(1))) {
		                System.out.println("This book has already been scanned/rented");
		                alreadyScanned = true;
		                break;
		            }
		        }

		        if (!alreadyScanned) {
		            rent.setRentArr(currentRent, userName, currentBooks.get(i)[3]);
		            System.out.println("Book Successfully Rented");
		        }
		        
		        break;
		        
		    } else {
		    	bookExist = false;
		    }
		}
		
		if (!bookExist) {
			System.out.println("This book isn't up for rent yet.");
		}
		
		currentRent = rent.getRentArr();
	}
	
	public static void returnBook(ArrayList<String[]> currentRent) {
		
		Scanner reader = new Scanner(System.in);
		String[] data = {};
		while (data.length == 0) {
			System.out.print("Scan the barcode on the book with the scanner e.g. C:\\Users\\wwwth\\OneDrive\\Desktop\\Barcode\\Barcode.png: ");
			String folderPath = reader.nextLine();
			data = BarcodeScanner.Scan(folderPath, BarcodeType.Code128);
		}
		final String bookCode = data[0];
		boolean bookRented = false;
		for (int i = 0; i < currentRent.size(); i++) {
			
			if (bookCode.substring(1).equals(currentRent.get(i)[1].substring(1))) {
				currentRent.remove(i);
				System.out.println("Book Successfully Returned");
				bookRented = true;
				break;
			} else {
				bookRented = false;
			}
		}
		if (!bookRented) {
			System.out.println("Please rent the book first.");
		}
	}
}
