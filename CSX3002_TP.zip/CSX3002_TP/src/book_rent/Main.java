//Sithu Win San - 6726077
//Aung Thura Hein - 6726135

package book_rent;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// DATABASE
		ArrayList<String[]> currentUsers = new ArrayList<String[]>();
		ArrayList<String[]> currentBooks = new ArrayList<String[]>();
		ArrayList<String[]> currentRent = new ArrayList<String[]>();
		ArrayList<String[]> alreadyReminded = new ArrayList<String[]>();
		String[] user0 = {"Admin", "0", "www.thuyawin2004@gmail.com"};
		String[] user1 = {"Aung", "111", "austinketchan8888@gmail.com"};
		
		String[] book0 = {"Harry Potter", "J.K Rowling", "1995", "AA0000"};
		String[] book1 = {"Girly Pop", "John Smith", "2017", "AA0001"};
		String[] book2 = {"Pride & Prejudice", "Jane Austen", "1813", "AA0002"};
		
		String[] rent0 = {"Admin", "AA0000", "7"};
		String[] rent1 = {"Aung", "AA0001", "7"};
		
		currentUsers.add(user0);
		currentUsers.add(user1);
		
		currentBooks.add(book0);
		currentBooks.add(book1);
		currentBooks.add(book2);
		
		currentRent.add(rent0);
		currentRent.add(rent1);
		
		Scanner reader = new Scanner(System.in);
		LocalDate lastDate = LocalDate.now();
		System.out.print("Please enter the admin's Google account APP password for sending emails: "); //gzjf jvlc byrd upox
		String emailPassword = reader.nextLine();
		
		while (true) {
			
			boolean adminExist = Data.checkAdminExist(currentUsers);
			
			while (!adminExist) {
				Login.clearConsole();
				System.out.println("Please add Admin to continue. Library Code: 0");
				Admin.addUser(currentUsers);
				adminExist = Data.checkAdminExist(currentUsers);
				if (adminExist) {
					System.out.print("Please enter the admin's Google account APP password for sending emails: ");
					emailPassword = reader.nextLine();
				}
			}
			
			LocalDate currentDate = LocalDate.now();
			Notify.calculateDate(currentRent, lastDate, currentDate);
			Notify.notifyDate(currentUsers, currentRent, alreadyReminded, emailPassword);
			Login.clearConsole();
			
			int foundIndex = Login.displayMethod(currentUsers);
			int level = Login.checkAccessLevel(currentUsers, foundIndex);
			
			if (level == 0) {
				Login.AdminOptions(currentUsers, currentBooks, currentRent, foundIndex, emailPassword);
			}
			
			if (level == 1) {
				Login.MemberOptions(currentUsers, currentBooks, currentRent, foundIndex);
			}
		}
	}
}
