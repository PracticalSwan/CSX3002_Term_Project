package book_rent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Login {
	
	public static int displayMethod(ArrayList<String[]> currentUsers) {
		Scanner reader = new Scanner(System.in);
		boolean found = false;
		int foundIndex = 0;
		while (!found) {
			System.out.println("Welcome to Library System");
			System.out.println("------Login------");
			
			System.out.print("Please scan your library card: ");
			String ID = reader.nextLine();
			
			for (int i = 0; i < currentUsers.size(); i++) {
				if (currentUsers.get(i)[1].equals(ID)) {
					foundIndex = i;
					found = true;
				}
			}
			if (!found) {
				System.out.println("This user doesn't exist in the library database.");
			}
		}
		clearConsole();
		System.out.println("Welcome Mr. " + currentUsers.get(foundIndex)[0]);
		return foundIndex;
	}
	
	public static int checkAccessLevel(ArrayList<String[]> currentUsers, int foundIndex) {
		if (currentUsers.get(foundIndex)[1].equals("0")) {
			return 0;
		} else {
			return 1;
		}
	}
	
	public static void AdminOptions(ArrayList<String[]> currentUsers, ArrayList<String[]> currentBooks, ArrayList<String[]> currentRent, int foundIndex, String emailPassword) {
		System.out.println("Option 1: Add Users");
		System.out.println("Option 2: Remove Users");
		System.out.println("Option 3: Add Books");
		System.out.println("Option 4: Remove Books");
		System.out.println("Option 5: Display the list of Books in the library");
		System.out.println("Option 6: Display the list of Registered Users");
		System.out.println("Option 7: Display the list of Books Rented by Users");
		System.out.println("Option 8: Generate Bar Code Image");
		System.out.println("Option 9: Change Email Address");
		System.out.println("Option 10: Display the list of Books you have rented");
		System.out.println("Option 11: Rent a Book");
		System.out.println("Option 12: Return a Book");
		System.out.println("Option 13: Sign Out");
		
		while (true) {
			try {
				System.out.println();
				Scanner reader = new Scanner(System.in);
				System.out.print("Select an option to commence: ");
				int option = reader.nextInt();
				
				if (option == 1) {
					Admin.addUser(currentUsers);
				} else {
					if (option == 2) {
						Admin.removeUser(currentUsers, currentRent);
						if (!Data.checkAdminExist(currentUsers)) {
							break;
						}
					} else {
						if (option == 3) {
							Admin.addBook(currentBooks);
						} else {
							if (option == 4) {
								Admin.removeBook(currentBooks, currentRent);
							} else {
								if (option == 5) {
									Data.displayBookList(currentBooks, 0);
								} else {
									if (option == 6) {
										Data.displayUserList(currentUsers);
									} else {
										if (option == 7) {
											Data.displayRentList(currentRent);
										} else {
											if (option == 8) {
												Admin.generateBarCode(currentBooks);
											} else {
												if (option == 9) {
													Admin.changeEmail(currentUsers, foundIndex, emailPassword);
												} else {
													if (option == 10) {
														Data.displayRentedBooks(currentUsers, currentBooks, currentRent, foundIndex);
													} else {
														if (option == 11) {
															Admin.rentBook(currentUsers, currentBooks, currentRent, foundIndex);
														} else {
															if (option == 12) {
																Admin.returnBook(currentRent);
															} else {
																if (option == 13) {
																	break;
																} else {
																	System.out.println("Please choose/enter a valid option.");
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			} catch (Exception ex){
				System.err.println("Only number input is allowed!!!");
			}
		}	
	}
	
	public static void MemberOptions(ArrayList<String[]> currentUsers, ArrayList<String[]> currentBooks, ArrayList<String[]> currentRent, int foundIndex) {
		System.out.println("Option 1: Display the list of Books in the library");
		System.out.println("Option 2: Change Email Address");
		System.out.println("Option 3: Display the list of Books you have rented");
		System.out.println("Option 4: Rent a Book");
		System.out.println("Option 5: Return a Book");
		System.out.println("Option 6: Sign Out");
		while (true) {
			try {
				System.out.println();
				Scanner reader = new Scanner(System.in);
				System.out.print("Select an option to commence: ");
				int option = reader.nextInt();
				
				if (option == 1) {
					Data.displayBookList(currentBooks, 1);
				} else {
					if (option == 2) {
						Member.changeEmail(currentUsers, foundIndex);
					} else {
						if (option == 3) {
							Data.displayRentedBooks(currentUsers, currentBooks, currentRent, foundIndex);
						} else {
							if (option == 4) {
								Member.rentBook(currentUsers, currentBooks, currentRent, foundIndex);
							} else {
								if (option == 5) {
									Member.returnBook(currentRent);
								} else {
									if (option == 6) {
										break;
									} else {
										System.out.println("Please choose/enter a valid option.");
									}
								}
							}
						}
					}
				}
			} catch (Exception ex) {
				System.err.println("Only number input is allowed!!!");
			}
		}
	}
	
	public static void clearConsole() {
	    try {
	    	
	        if (System.getProperty("os.name").contains("Windows")) {
	            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
	        } else {
	            System.out.print("\033\143");
	        }
	        
	    } catch (IOException | InterruptedException ex) {
	    	
	    }
	}
}
