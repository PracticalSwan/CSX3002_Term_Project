package book_rent;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;

import org.krysalis.barcode4j.HumanReadablePlacement;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;

// Encapsulation
public class Data {
	
	private ArrayList<String[]> books;
	private ArrayList<String[]> users;
	private ArrayList<String[]> rent;
	
	public Data(ArrayList<String[]> arr) {
		this.books = arr;
		this.users = arr;
		this.rent = arr;
	}
	
	public ArrayList<String[]> getRentArr() {
		return rent;
	}

	public void setRentArr(ArrayList<String[]> rent, String name, String bookID) {
		ArrayList<String[]> newRentArr = rent;
		String time = "7";
		String[] newRent = {name, bookID, time};
		newRentArr.add(newRent);
		this.rent = newRentArr;
	}

	public ArrayList<String[]> getBookArr() {
		return books;
	
	}
	
	public void setBookArr(ArrayList<String[]> books, String book_name, String book_author, String book_year, String book_code) {
		ArrayList<String[]> newBooksArr = books;
		String[] newBook = {book_name, book_author, book_year, book_code};
		boolean codeExist = false;
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i)[3].equals(newBook[3])) {
				System.out.println("Failed to add book. Reason: code already exists, please assign another code for the book.");
				codeExist = true;
				break;
			}
		}
		
		if (!codeExist) {
			newBooksArr.add(newBook);
			System.out.println("Book Successfully Added.");
		}
		
		this.books = newBooksArr;
	}

	public ArrayList<String[]> getUserArr() {
		return users;
	}

	public void setUserArr(ArrayList<String[]> users, String name, String libraryNum, String email) {
		ArrayList<String[]> newUserArr = users; 
		String[] newUser = {name, libraryNum, email};
		boolean userExist = false;
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i)[0].equals(newUser[0])) {
				System.out.println("Failed to add user. Reason: user already exists, please remove first to change ID.");
				userExist = true;
				break;
			}
			
			if (libraryNum.equals("0") && libraryNum.equals(users.get(i)[1])) {
				System.out.println("Failed to add user. Reason: only one Admin can exists at a time, please remove the existing Admin.");
				userExist = true;
				break;
			} else {
				
				if (libraryNum.equals(users.get(i)[1])) {
					System.out.println("Failed to add user. Reason: library number already assigned, please remove the user assigned.");
					userExist = true;
					break;
				}
			}
		}
		
		if (!userExist) {
			newUserArr.add(newUser);
			System.out.println("User Successfully Added.");
		}
		
		this.users = newUserArr;
		
	}
	
	public static void displayUserList(ArrayList<String[]> currentUsers) {
		System.out.println("---The list of registered users---");
		for (String[] users : currentUsers) {
			System.out.print(Arrays.toString(users));
		}
		
		System.out.println();
	}
	
	public static void displayBookList(ArrayList<String[]> currentBooks, int level) {
		System.out.println("---The list of books available---");
		if (level == 0) {
			
			for (String[] books : currentBooks) {
				System.out.print(Arrays.toString(books));
			}
			System.out.println();
		} else {
			
			for (String[] books : currentBooks) {
				books = remove(books, 3);
				System.out.print(Arrays.toString(books));
			}
			
			System.out.println();
		}
		
	}
	
	public static void displayRentList(ArrayList<String[]> currentRent) {
		System.out.println("---The list of rented users---");
		for (String[] rent : currentRent) {
			System.out.print(Arrays.toString(rent));
		}
		
		System.out.println();
	}
	
	public static void displayRentedBooks(ArrayList<String[]> currentUsers, ArrayList<String[]> currentBooks, ArrayList<String[]> currentRent, int foundIndex) {
		String name = currentUsers.get(foundIndex)[0];
		
		if (currentRent.isEmpty()) {
			System.out.println("You haven't rented any books.");
		} else {
			ArrayList<String> rentedBooks = new ArrayList<String>();
			
			for (int i = 0; i < currentBooks.size(); i++) {
				for (int j = 0; j < currentRent.size(); j++) {
					if (currentRent.get(j)[0].equals(name) && currentRent.get(j)[1].equals(currentBooks.get(i)[3])) {
						rentedBooks.add(currentBooks.get(i)[0]);
					}
				}
			}
			
			if (rentedBooks.isEmpty()) {
				System.out.println("You haven't rented any books.");
			} else {
				System.out.println("---The list of books you have rented---");
				for (String rentBook : rentedBooks) {
					System.out.println("- " + rentBook);
				}
			}
		}
	}
	
	public static boolean checkAdminExist(ArrayList<String[]> currentUsers) {
		boolean adminExist = false;
		
		for (int i = 0; i < currentUsers.size(); i++) {
			if (currentUsers.get(i)[1].equals("0")) {
				adminExist = true;
				break;
			}
		}
		return adminExist;
	}
	
	public static void createImage(String image_name, String myString, String folderPath)  {
		try {
			
		Code128Bean code128 = new Code128Bean();
		code128.setHeight(20f);
		code128.setModuleWidth(0.5);
		code128.setQuietZone(10);
		code128.doQuietZone(true);
		code128.setMsgPosition(HumanReadablePlacement.HRP_NONE);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		BitmapCanvasProvider canvas = new BitmapCanvasProvider(baos, "image/x-png", 300, BufferedImage.TYPE_BYTE_BINARY, false, 0);
		code128.generateBarcode(canvas, myString);
		canvas.finish();
		
        File folder = new File(folderPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }

        File outputFile = new File(folderPath + image_name);
        int count = 1;
        while (outputFile.exists()) {
            String newName = image_name.replaceFirst("(\\.png)$", "_" + count + "$1");
            outputFile = new File(folderPath + newName);
            count++;
        }
        
        FileOutputStream fos = new FileOutputStream(outputFile);
		fos.write(baos.toByteArray());
		fos.flush();
		fos.close();
		
		} catch (Exception e) {
			
		}
	}
	
	public static String[] remove(String[] arr, int in) {
        if (arr == null || in < 0 || in >= arr.length) {
            return arr;
        }
        
        String[] arr2 = new String[arr.length - 1];

        for (int i = 0, k = 0; i < arr.length; i++) {
            if (i == in) {
            	continue;
            }
            
            arr2[k++] = arr[i];
        }
        
        return arr2;
    }
}
