package book_rent;

import java.util.ArrayList;
import java.util.Scanner;

public class Admin extends Member {
	
	public static void addUser(ArrayList<String[]> currentUsers) {
		Data data = new Data(currentUsers);
		String loop = "Y";
		while (loop.equals("Y")) {
			Scanner reader = new Scanner(System.in);
			System.out.print("Enter Full Name: ");
			final String user_name = reader.nextLine();
			System.out.print("Enter Library Number: ");
			final String user_ID = reader.nextLine();
			System.out.print("Enter Email: ");
			final String user_email = reader.nextLine();
			if (!user_email.contains("@gmail.com")) {
				System.out.println("Failed to add user. Reason: Invalid email address");
				continue;
			}
			
			data.setUserArr(currentUsers, user_name, user_ID, user_email);
			currentUsers = data.getUserArr();
			
			System.out.print("Add more users? (Y/N): ");
			loop = reader.nextLine().toUpperCase();
		}
	}
	
	public static void removeUser(ArrayList<String[]> currentUsers, ArrayList<String[]> currentRent) {
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter username to remove: ");
		String removeName = reader.nextLine();
		boolean nameExist = false;
		boolean rentedUser = false;
		
		for (int i = 0; i < currentRent.size(); i++) {
			if (removeName.equals(currentRent.get(i)[0])) {
				System.out.println("User " + currentRent.get(i)[0] + " has rented a book. Please wait for him/her to return the book.");
				rentedUser = true;
				nameExist = true;
				break;
			}
		}
		
		if (!rentedUser) {
			for (int i = 0; i < currentUsers.size(); i++) {
				if (removeName.equals(currentUsers.get(i)[0])) {
					currentUsers.remove(i);
					System.out.println("User " + removeName + " has been removed.");
					nameExist = true;
					break;
				}
			}
		}
		
		if (!nameExist) {
			System.out.println("User " + removeName + " does not exist.");
		}
	}

	public static void addBook(ArrayList<String[]> currentBooks) {
		Data data = new Data(currentBooks);
		String loop = "Y";
		while (loop.equals("Y")) {
			Scanner reader = new Scanner(System.in);
			System.out.print("Enter Book Name: ");
			final String book_name = reader.nextLine();
			System.out.print("Enter Book Author: ");
			final String book_author = reader.nextLine();
			System.out.print("Enter Book Published Year: ");
			final String book_year = reader.nextLine();
			System.out.print("Enter Book Unique code: ");
			final String book_code = reader.nextLine();
			
			data.setBookArr(currentBooks, book_name, book_author, book_year, book_code);
			currentBooks = data.getBookArr();
			
			System.out.print("Add more books? (Y/N): ");
			loop = reader.nextLine().toUpperCase();
		}
	}
	
	public static void removeBook(ArrayList <String[]> currentBooks, ArrayList <String[]> currentRent) {
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter book code to remove: ");
		String removeBook = reader.nextLine();
		boolean codeExist = false;
		boolean rentedBook = false;
		
		for (int i = 0; i < currentRent.size(); i++) {
			if (removeBook.equals(currentRent.get(i)[1])) {
				System.out.println("User " + currentRent.get(i)[0] + " has rented this book. Please wait for him/her to return the book.");
				rentedBook = true;
				codeExist = true;
				break;
			}
		}
		
		if (!rentedBook) {
			for (int i = 0; i < currentBooks.size(); i++) {
				if (removeBook.equals(currentBooks.get(i)[3])) {
					System.out.println(currentBooks.get(i)[0] + " with the code " + removeBook + " has been removed.");
					currentBooks.remove(i);
					codeExist = true;
					break;
				}
			}
		}
		
		if (!codeExist) {
			System.out.println("The code " + removeBook + " does not exist.");
		}
	}
	
	public static void generateBarCode(ArrayList<String[]> currentBooks) {
		
		Scanner reader = new Scanner(System.in);
		System.out.print("Enter book code: ");
		String bookCode = reader.nextLine();
		String bookName = "Unknown_Book";
		System.out.print("Enter folder path e.g. C:\\Users\\wwwth\\OneDrive\\Desktop\\Barcode\\: ");
		String folderPath = reader.nextLine();
		
		for (int i = 0; i < currentBooks.size(); i++) {
			if (currentBooks.get(i)[3].equals(bookCode)) {
				bookName = currentBooks.get(i)[0];
			}
		}
		
		Data.createImage(bookName + ".png", bookCode, folderPath);
		System.out.println("Finished Creating Barcode Image.");
	}
	
	public static void changeEmail(ArrayList<String[]> currentUsers, int foundIndex, String emailPassword) {
		Scanner reader = new Scanner(System.in);
		
		System.out.print("Enter your new email: ");
		String newEmail = reader.nextLine();
		if (newEmail.contains("@gmail.com")) {
			currentUsers.get(foundIndex)[2] = newEmail;
			System.out.println("Email Successfully Changed.");
			System.out.print("Please enter the admin's Google account APP password for sending emails: ");
			emailPassword = reader.nextLine();
		} else {
			System.out.println("Failed to change Email address. Reason: Invalid email address.");
		}
	}
}
