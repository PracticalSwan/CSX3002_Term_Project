package book_rent;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Notify {
	
	public static void calculateDate(ArrayList<String[]> currentRent, LocalDate lastDate, LocalDate currentDate) {
		int remainingDate = (int) ChronoUnit.DAYS.between(lastDate, currentDate);
		if (remainingDate >= 1) {
			for (int i = 0; i < currentRent.size(); i++) {
				int day = Integer.parseInt(currentRent.get(i)[2]);
				int remainingDay = day - 1;
				String[] temArr = {currentRent.get(i)[0], currentRent.get(i)[1], String.valueOf(remainingDay)};
				currentRent.set(i, temArr);
			}
			lastDate = LocalDate.now();
		}
	}
	
	public static void notifyDate(ArrayList<String[]> currentUsers, ArrayList<String[]> currentRent, ArrayList<String[]> alreadyReminded, String emailPassword) {
		String email = null;
		String sender = null;
		for (String[] currentRentInfo : currentRent) {
			LocalDate dueDate = LocalDate.now().plusDays(Integer.parseInt(currentRentInfo[2]));
			LocalDate today = LocalDate.now();
			int remainingDate = (int) ChronoUnit.DAYS.between(today, dueDate);
			
			if (remainingDate <= 3) {
				for (String[] userInfo : currentUsers) {
					
					if (userInfo[0].equals(currentRentInfo[0])) {
						email = userInfo[2];
						break;
					}
				}
				
				if (email != null && !alreadyReminded.contains(currentRentInfo)) {
					for (int i = 0; i < currentUsers.size(); i++) {
						if (currentUsers.get(i)[1] == "0") {
							sender = currentUsers.get(i)[2];
							break;
						}
					}
					sendEmail(email, sender, emailPassword);
					alreadyReminded.add(currentRentInfo);
				}
			}
		}
		
		for (int i = 0; i < alreadyReminded.size(); i++) {
			if (!currentRent.contains(alreadyReminded.get(i))) {
				alreadyReminded.remove(i);
			}
		}
	}
	
	public static void sendEmail(String email, String sender, String emailPassword) {
		try {
			
			String host = "smtp.gmail.com";
			String from = sender;
			String password = emailPassword;
			
			Properties props = new Properties();
			props.put("mail.smtp.host", host);
			props.put("mail.smtp.port", "587");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.starttls.enable", "true");
			
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
				}
			});
			
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));
			message.setSubject("Book Rental Reminder");
			message.setText("This is a reminder that your book is due soon. Please return it on time.");
			
			Transport.send(message);
			System.out.println("Email sent successfully to: " + email);
			
			} catch (MessagingException mex) {
				mex.printStackTrace();
			}
	}
}