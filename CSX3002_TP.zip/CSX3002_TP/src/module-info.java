module CSX3002_TP {
	exports book_rent;

	requires OnBarcode.BarcodeReader;
	requires barcode4j;
	requires java.desktop;
	requires java.mail;
	requires activation;
}